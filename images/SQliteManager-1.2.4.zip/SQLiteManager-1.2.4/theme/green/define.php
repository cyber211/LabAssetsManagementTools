<?php
/**
* Web based SQLite management
* Some Theme defines
* @package Green Theme for SQLiteManager
* @author Tanguy Pruvot
* @version $Id: define.php,v 1.8 2005/06/05 17:58:37 freddy78 Exp $ $Revision: 1.8 $
*/

$QueryResultAlign			= 'center';
$displayQueryTitleColor = '#e7dfce';
$displayQueryBgColor 	= '#e7dfce';

$browseColor1				= '#f7f3ef';
$browseColor2				= '#e7dfce';
$browseColorOver			= '#EAFFEA';
$browseColorClick			= '#FFFFAA';

$jsmenu_style = 'hbr';

$theme_author  = '<br/>Tanguy Pruvot';
$theme_contact = 'mailto:tanguy.pruvot at laposte.net';
?>
